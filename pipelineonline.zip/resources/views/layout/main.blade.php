<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    {{-- <link href="/css/bootstrap.min.css" rel="stylesheet" type="text/css" integrity="sha384-EVSTQN3azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> --}}

    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


    <link href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css">


    <script type="text/javascript" src="js/jquery.min.js"></script>

     @yield('assets')


    <style type="text/css">
      td{
        font-family: Calibri;
        font-size: 12px;
      }
      th{
        font-size: 12px;
        text-align: center;
        vertical-align: middle;        
      }
      .text-right{
        text-align: right;
      }
      .text-left{
        text-align: left;
      }
      .text-center{
        text-align: center;
      }
      .badge{
        font-size: 0.9em;
      }
      a{
        text-decoration: none;
      }
    </style>
     
    <title>Employee @yield('title')</title>
  </head>
  <body>

  	@include('layout.navbar')

    <div class="container">

    <br>
    <br>
    <br>
    @yield('container')

    </div>



    @yield('bodybottom')
    <script src="{{ asset('js/bootstrap.bundle.min.js') }}" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>



  </body>

  
</html>