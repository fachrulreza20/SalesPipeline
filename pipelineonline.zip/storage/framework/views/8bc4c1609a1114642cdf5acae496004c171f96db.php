<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    

    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


    <link href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css">


    <script type="text/javascript" src="js/jquery.min.js"></script>

     <?php echo $__env->yieldContent('assets'); ?>


    <style type="text/css">
      td{
        font-family: Calibri;
        font-size: 12px;
      }
      th{
        font-size: 12px;
        text-align: center;
        vertical-align: middle;        
      }
      .text-right{
        text-align: right;
      }
      .text-left{
        text-align: left;
      }
      .text-center{
        text-align: center;
      }
      .badge{
        font-size: 0.9em;
      }
      a{
        text-decoration: none;
      }
    </style>
     
    <title>Employee <?php echo $__env->yieldContent('title'); ?></title>
  </head>
  <body>

  	<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">

    <br>
    <br>
    <br>
    <?php echo $__env->yieldContent('container'); ?>

    </div>



    <?php echo $__env->yieldContent('bodybottom'); ?>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>



  </body>

  
</html><?php /**PATH E:\LARAVEL8\pipelineonline\resources\views/layout/main.blade.php ENDPATH**/ ?>