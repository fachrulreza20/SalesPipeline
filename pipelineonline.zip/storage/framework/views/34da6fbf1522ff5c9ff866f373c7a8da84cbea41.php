

<?php $__env->startSection('title', 'Create'); ?>

<?php $__env->startSection('assets'); ?>
    <link rel="stylesheet" href="/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>
  
<a href="/outlet">back</a>  
<h3>Add New outlet</h3>
<br>
<form class="form" action="/outletStore" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>

  <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">outlet Code</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="outlet_code" placeholder="contoh: ID0010008">
    </div>
  </div>

  <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">outlet Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="outlet_name" placeholder="contoh: KCP Medan Sukaramai">
    </div>
  </div>

  <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Pilih Area</label>
    <div class="col-sm-10">
     
      <select class="form-select" name="outlet_area">
        <option value="Area Medan Kota">Area Medan Kota</option>
        <option value="Area Medan Raya">Area Medan Raya</option>
        <option value="Area Batam">Area Batam</option>
        <option value="Area Pekanbaru">Area Pekanbaru</option>
        <option value="Area Pematangsiantar">Area Pematangsiantar</option>
      </select>
    </div>
  </div>

  <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Region</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="outlet_region" placeholder="contoh: Region Medan" value="Region Medan">
    </div>
  </div>

  <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Pilih Bank Legacy</label>
    <div class="col-sm-10">
     
      <select class="form-select" name="outlet_bank">
        <option value="bsm">BSM</option>
        <option value="bris">BNIS</option>
        <option value="bnis">BRIS</option>
      </select>
    </div>
  </div>



 
 <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label"></label>
   <div class="col-auto">
      <button type="submit" class="btn btn-primary mb-3">Submit</button>
    </div>
 </div>

</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL8\pipelineonline\resources\views/outlet/create.blade.php ENDPATH**/ ?>