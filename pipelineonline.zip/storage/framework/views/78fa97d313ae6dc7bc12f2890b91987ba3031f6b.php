<?php echo e($slot); ?>

<?php /**PATH E:\LARAVEL8\pipelineonline\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>