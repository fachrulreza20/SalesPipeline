

<?php $__env->startSection('title', 'Pipeline'); ?>

<?php $__env->startSection('assets'); ?>
    <link rel="stylesheet" href="/css/font-awesome.min.css">

<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>
  
<a href="/pipeline">back</a>  
<h3>Edit Data Pipeline</h3>
<br>
<form autocomplete="off" class="form-inline" action="/pipelineUpdate/<?php echo e($pipelineShow->id); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>

  <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Nama Nasabah</label>
    <div class="col-sm-10">
      <input required="true" type="text" class="form-control" name="pipeline_nama_nasabah" value="<?php echo e($pipelineShow->pipeline_nama_nasabah); ?>" >
    </div>
  </div>


 <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Nominal</label>
    <div class="col-sm-10">
      <input required="true" type="text" class="form-control" name="pipeline_nominal" value="<?php echo e($pipelineShow->pipeline_nominal); ?>">
    </div>
  </div>

 <div class="mb-3 row"> 
    <label for="RezaField" class="col-sm-2 col-form-label">Progress</label>
    <div class="col-sm-10">

      <select required="true" class="form-select" name="pipeline_progress">
        <?php $__currentLoopData = $progressCollection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $progress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e(($pipelineShow->pipeline_progress == $progress->id) ? 'selected' : ''); ?> value="<?php echo e($progress->id); ?>"><?php echo e($progress->progress_ket); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

    </div>
  </div>

 <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Segmen</label>
    <div class="col-sm-10">
      <select required="true" class="form-select" name="pipeline_segmen">
        <?php $__currentLoopData = $segmentCollection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e(($pipelineShow->pipeline_segmen == $segment->id) ? 'selected' : ''); ?> value="<?php echo e($segment->id); ?>"><?php echo e($segment->segmen_ket); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
  </div>


 <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Proyeksi Cair </label>
    <div class="col-sm-6">

        <?php

          $monthNumber = date('m');
          $weekNumber = $weekNumber;

        ?>

        <div class="form-inline">
          <select required="true" name="pipeline_proyeksiCairMonth" class="form-select mb-2">
            <option value="01" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '01') ? 'selected' : ''); ?>>Bulan Januari</option>
            <option value="02" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '02') ? 'selected' : ''); ?>>Bulan Februari</option>
            <option value="03" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '03') ? 'selected' : ''); ?>>Bulan Maret</option>
            <option value="04" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '04') ? 'selected' : ''); ?>>Bulan April</option>
            <option value="05" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '05') ? 'selected' : ''); ?>>Bulan Mei</option>
            <option value="06" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '06') ? 'selected' : ''); ?>>Bulan Juni</option>
            <option value="07" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '07') ? 'selected' : ''); ?>>Bulan Juli</option>
            <option value="08" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '08') ? 'selected' : ''); ?>>Bulan Agustus</option>
            <option value="09" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '09') ? 'selected' : ''); ?>>Bulan September</option>
            <option value="10" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '10') ? 'selected' : ''); ?>>Bulan Oktober</option>
            <option value="11" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '11') ? 'selected' : ''); ?>>Bulan November</option>
            <option value="12" <?php echo e(($pipelineShow->pipeline_proyeksiCairMonth == '12') ? 'selected' : ''); ?>>Bulan Desember</option>
          </select>

          <select required="true" name="pipeline_proyeksiCairWeek" class="form-select mb-2">
            <option value="1" <?php echo e(($pipelineShow->pipeline_proyeksiCairWeek == '1') ? 'selected' : ''); ?>> Week 1</option>
            <option value="2" <?php echo e(($pipelineShow->pipeline_proyeksiCairWeek == '2') ? 'selected' : ''); ?>> Week 2</option>
            <option value="3" <?php echo e(($pipelineShow->pipeline_proyeksiCairWeek == '3') ? 'selected' : ''); ?>> Week 3</option>
            <option value="4" <?php echo e(($pipelineShow->pipeline_proyeksiCairWeek == '4') ? 'selected' : ''); ?>> Week 4</option>
            <option value="5" <?php echo e(($pipelineShow->pipeline_proyeksiCairWeek == '5') ? 'selected' : ''); ?>> Week 5</option>
          </select>

        </div>

      <input required="true" type="hidden" class="form-control datepicker" name="pipeline_proyeksiCairDate" value="2021-01-01">

  </div>   
</div>

 
 
 <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Nomor Loan (jika sudah cair)</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_noloan" required="true" value="<?php echo e($pipelineShow->pipeline_noloan); ?>">
      <small class="text-muted">Tulis 0 jika belum Cair</small>
    </div>
  </div>

  <input required="true" type="hidden" class="form-control" name="pipeline_nip" value="<?php echo e($employeeCollection->nip); ?>">
  <input required="true" type="hidden" class="form-control" name="pipeline_jabatan" value="<?php echo e($employeeCollection->jabatan); ?>">
  <input required="true" type="hidden" class="form-control" name="pipeline_outletCode" value="<?php echo e($employeeCollection->outletCode); ?>">

 <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Keterangan</label>
    <div class="col-sm-10">
      <input required="true" type="text" class="form-control" name="pipeline_ket" value="<?php echo e($pipelineShow->pipeline_ket); ?>" >
    </div>
  </div>


  <input required="true" type="hidden" class="form-control" name="pipeline_status" value="<?php echo e($pipelineShow->pipeline_status); ?>">


 <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Jenis</label>
    <div class="col-sm-10">
      <select required="true" class="form-control" name="pipeline_jenis">
        <option <?php echo e(($pipelineShow->pipeline_jenis == 'baru') ? 'selected' : ''); ?> value="baru">Baru</option>
        <option <?php echo e(($pipelineShow->pipeline_jenis == 'topup') ? 'selected' : ''); ?> value="topup">Top Up</option>
      </select>
    </div>
  </div>


 
 <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label"></label>
   <div class="col-auto">
      <button type="submit" class="btn btn-sm btn-primary mb-3">Submit</button>
    </div>
 </div>

</form>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('bodybottom'); ?>

<script type="text/javascript">
 $(function(){
  $(".datepicker").datepicker({
      format: 'yyyy-mm-dd',
      autoclose: true,
      todayHighlight: true,
  });
 });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL8\pipelineonline\resources\views/pipeline/show.blade.php ENDPATH**/ ?>