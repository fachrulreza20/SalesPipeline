

<?php $__env->startSection('title', 'Index'); ?>



<?php $__env->startSection('container'); ?>

      <a href='/segmentCreate' class="btn btn-primary">Add New</a>      

      <div class="row mt-2">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success" role="alert">
              <?php echo e($message); ?>

          </div>
        <?php endif; ?>
      </div>

      <table class="table mt-2 table-bordered table-hover table-sm table-responsive">
        <thead class="thead-dark">
          <tr>
            <th class="text-center" scope="col">#</th>
            <th class="text-center" scope="col">Segment_Ket</th>
            <th class="text-center" scope="col">Modified</th>

            <th class="text-center" scope="col">Aksi</th>
          </tr>
        </thead>
        <tbody>

          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
              <td scope="row"><?php echo e($row->id); ?></td>
              <td><?php echo e($row->segment_ket); ?></td>
              <td><?php echo e($row['updated_at']->format('d M Y h:i')); ?></td>
              <td>
                  <a href="/show/<?php echo e($row->id); ?>" class="btn btn-success m-1">Edit</button>
                  <a href="#" class="btn btn-danger hapus" data-id="<?php echo e($row->id); ?>" data-nama="<?php echo e($row->segment_ket); ?>">Delete</a>
              </td>
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('bodybottom'); ?>

<script>

  $('.hapus').click(function(){

    var id = $(this).attr('data-id');
    var namapegawai = $(this).attr('data-nama');

    Swal.fire({
      title: 'Anda Yakin?',
      text: "Anda akan menghapus pegawai nama : "+namapegawai+"",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya. Hapus Data'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location = "/segmenteDelete/"+id
        Swal.fire(
          'Data Berhasil dihapus!',
          'Sip.',
          'success'
        )
      }
    })
  })

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL8\pipelineonline\resources\views/segmen/index.blade.php ENDPATH**/ ?>