

<?php $__env->startSection('title', 'Employee'); ?>



<?php $__env->startSection('container'); ?>
      <h4>Data Employee</h4>
      <a href='/employeeCreate' class="btn btn-sm btn-primary mt-2">Add New</a>      

      <div class="row mt-2">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success" role="alert">
              <?php echo e($message); ?>

          </div>
        <?php endif; ?>
      </div>

      <table class="table mt-2 table-bordered table-hover table-sm table-responsive text-xsmall">
        <thead class="table-secondary">
          <tr>
            <th class="text-center" scope="col">#</th>
            <th class="text-center" scope="col">NIP</th>
            <th class="text-center" scope="col">Nama</th>
            <th class="text-center" scope="col">Unit Kerja</th>
            <th class="text-center" scope="col">Jabatan</th>
            <th class="text-center" scope="col">Email</th>
            <th class="text-center" scope="col">Status</th>
            <th class="text-center" scope="col">Modified</th>

            <th class="text-center" scope="col">Aksi</th>
          </tr>
        </thead>
        <tbody>

          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
              <td scope="row"><?php echo e($data->firstItem() + $key); ?></td>
              <td><?php echo e($row->nip); ?></td>
              <td><?php echo e($row->nama); ?></td>
              <td><?php echo e($row->getOutlet->outlet_name); ?></td>
              <td><?php echo e($row->getJabatan->jabatan_ket); ?></td>
              <td><?php echo e($row->getJabatan->email); ?></td>
              <td><?php echo e($row->pegawai_status); ?></td>
              <td><?php echo e($row['updated_at']->format('d M Y h:i')); ?></td>
              <td>
                  <a href="/employeeShow/<?php echo e($row->id); ?>" class="btn btn-sm btn-success m-1">Edit</button>
                  <a href="#" class="btn btn-sm btn-sm btn-danger hapus" data-id="<?php echo e($row->id); ?>" data-nama="<?php echo e($row->nama); ?>">Delete</a>
              </td>
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div>
        Showing
        <?php echo e($data->firstItem()); ?>

        to
        <?php echo e($data->lastItem()); ?>

        of
        <?php echo e($data->total()); ?>        
      </div>
      <br>
      <div class="pull-right"> 
        <?php echo e($data->links()); ?>

      </div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('bodybottom'); ?>

<script>

  $('.hapus').click(function(){

    var id = $(this).attr('data-id');
    var employee_ket = $(this).attr('data-nama');

    Swal.fire({
      title: 'Anda Yakin?',
      text: "Anda akan menghapus employee  : "+employee_ket+"",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya. Hapus Data'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location = "/employeeDelete/"+id
        Swal.fire(
          'Data Berhasil dihapus!',
          'Sip.',
          'success'
        )
      }
    })
  })

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL8\pipelineonline\resources\views/employee/index.blade.php ENDPATH**/ ?>