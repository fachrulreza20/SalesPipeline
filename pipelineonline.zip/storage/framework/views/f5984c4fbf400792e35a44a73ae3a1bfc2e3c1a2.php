

<?php $__env->startSection('title', 'Pipeline'); ?>

<?php $__env->startSection('assets'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>

      <div class="float-right">
        <a href='/pipelineExport' class="btn btn-sm btn-success" style="float: right;">Download Excel Pipeline</a>      
      </div>


      <div class="row mt-2">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success" role="alert">
              <?php echo e($message); ?>

          </div>
        <?php endif; ?>
      </div>
      <br>
      <h4>Data Pipeline</h4>

      <a href='/pipelineCreate' class="btn btn-sm btn-primary">Add New</a>      
      <table class="table mt-2 table-bordered table-hover table-sm table-responsive" id="pipelineyajra">
        <thead class="table-secondary">
          <tr>
            <th>#</th>
            <th>Nama Nasabah</th>
            <th>Nominal</th>
            <th>Progress</th>
            <th>Segmen</th>
            <th>Proyeksi Cair</th>
            <th>Nomor Loan</th>
            <th>Employee/Marketing</th>
            <th>Jabatan</th>
            <th>Outlet</th>
            <th>Ket</th>
            <th>Status</th>
            <th>Jenis</th>
            <th>Modified</th>
            <th>Aksi</th>
          </tr>
        </thead>
      </table>
  
<?php $__env->stopSection(); ?>



<?php $__env->startSection('bodybottom'); ?>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js"></script>

    
    <script type="text/javascript">

//      $(document).ready(function() {
//          $('#pipelineyajra').DataTable();
//      } );      


      $(document).ready(function() {
          $('#pipelineyajra').DataTable( {
              processing: true,
              serverSide: true,
              ajax: {
                  url: "<?php echo e(route('pipelineyajra')); ?>",
                  type: "GET",
              },
              columns: [
                {data: 'id', name: 'id' },              
                {data: 'pipeline_nama_nasabah', name: 'pipeline_nama_nasabah'},
                {data: 'pipeline_nominal', name: 'pipeline_nominal'},
                {data: 'get_progress.progress_ket', name: 'progress_ket'},
                {data: 'get_segment.segmen_ket', name: 'segmen_ket'},
                {data: 'pipeline_noloan', name: 'pipeline_noloan'},
                {data: 'pipeline_noloan', name: 'pipeline_noloan'},
                {data: 'get_employee.nama', name: 'nama'},
                {data: 'get_jabatan.jabatan_ket', name: 'jabatan_ket'},
                {data: 'get_outlet.outlet_name', name: 'outlet_name'},
                {data: 'pipeline_ket', name: 'pipeline_ket'},
                {data: 'pipeline_status', name: 'pipeline_status'},
                {data: 'pipeline_jenis', name: 'pipeline_jenis'},
                {data: 'updated_at', name: 'updated_at'},
                {data: 'updated_at', name: 'updated_at'},
              ],
          } );
      } );


    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL8\pipelineonline\resources\views/pipelineyajra/index.blade.php ENDPATH**/ ?>