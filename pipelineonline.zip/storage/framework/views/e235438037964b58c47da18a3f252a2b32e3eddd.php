

<?php $__env->startSection('title', 'Create'); ?>

<?php $__env->startSection('assets'); ?>
    <link rel="stylesheet" href="/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>
  
<a href="/pipeline">back</a>  
<h3>Add New Pipeline</h3>
<br>
<form class="form" action="/pipelineStore" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>

  <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Nama Nasabah</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_nama_nasabah">
    </div>
  </div>


 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Nominal</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_nominal">
    </div>
  </div>

 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Progress</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_progress">
    </div>
  </div>

 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Segmen</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_segmen">
    </div>
  </div>

 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Tgl Proyeksi Cair (datepicker)</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_proyeksiCairDate">
    </div>
  </div>

 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Week Proyeksi Cair (datepicker</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_proyeksiCairWeek">
    </div>
  </div>

 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Bulan Proy Cair (datepicker)</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_proyeksiCairMonth">
    </div>
  </div>

 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Nomor Loan (jika sudah cair)</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_noloan">
    </div>
  </div>

 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">NIP (hidden)</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_nip">
    </div>
  </div>

 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Jabatan (hidden)</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_jabatan">
    </div>
  </div>

 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Outlet Code (hidden)</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_outletCode">
    </div>
  </div>

 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Keterangan</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="pipeline_ket">
    </div>
  </div>


  <input type="hidden" class="form-control" name="pipeline_status" value="on">


 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label">Jenis</label>
    <div class="col-sm-10">
      <select class="form-control" name="pipeline_jenis">
        <option value="baru">Baru</option>
        <option value="topup">Top Up</option>
      </select>
    </div>
  </div>


 
 <div class="mb-3 row">
    <label for="inputPassword" class="col-sm-2 col-form-label"></label>
   <div class="col-auto">
      <button type="submit" class="btn btn-primary mb-3">Submit</button>
    </div>
 </div>

</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL8\pipelineonline\resources\views/segmen/create.blade.php ENDPATH**/ ?>