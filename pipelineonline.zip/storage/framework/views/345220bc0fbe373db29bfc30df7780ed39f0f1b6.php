

<?php $__env->startSection('title', 'Index'); ?>



<?php $__env->startSection('container'); ?>

      <div class="row mt-2">
        <?php if($message = Session::get('warning')): ?>
          <div class="alert alert-warning" role="alert">
              <?php echo e($message); ?>

          </div>
        <?php endif; ?>
      </div>

      <h4>Summary Pipeline Area</h4>

    <table>
      <tr>
     <td style="background-color: #f5f5f5; padding: 15px; width: 100%; border-radius: 5px"> 
      <h5>Summary Berdasarkan Segmen/Product</h5>
      <table class="table mt-2 table-bordered table-hover table-sm w-auto my-3">          
        <thead class="table-secondary">

            <tr>
               <th>Area</th>
               <?php $__currentLoopData = $segmens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <th><?php echo e($row->segmen_ket); ?></th>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
               <th>Total Area</th>
               <th>NOA Pipeline</th>
            </tr>
        </thead>
        <tbody>

          <?php
            $table = "";
            $totalArea_1 = 0;

            foreach($areapages_segmen_ket as $row){
            $totalArea_1=0;
            $table = $table."\n
                <tr>
                  <td class='text-left'>".$row->outlet_area."</td>";
                  
                     
                     foreach ($segmens as $segmen){ // dinamyc column from table segmens
                         $modified_segmen_ket = 'OS_'.$segmen->modified_segmen_ket; // because in query use "as OS_"
                         $table = $table."<td class='text-right'>".number_format($row->{$modified_segmen_ket},0)."</td>"; // dinamyc column of collection use $collection->{$var}

                         $totalArea_1 = $totalArea_1 + $row->{$modified_segmen_ket}; 
                     }
                  $table = $table."
                  <td class='text-right'><b>".number_format($totalArea_1,0)."</b></td>
                  <td class='text-center'><b>".$row->NOA."</b></td>                    
                </tr>
            ";
            }
            echo $table;
          ?>
        </tbody>
      </table>



















      <br>
      <h5>Summary Berdasarkan Divisi</h5>

      <table class="table mt-2 table-bordered table-hover table-sm w-auto my-3">          
        <thead class="table-secondary">

            <tr>
               <th>Area</th>
               <?php $__currentLoopData = $segmens_divisi_only; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <th><?php echo e($row->divisi); ?></th>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
               <th>Total Area</th>
               <th>NOA Pipeline</th>
            </tr>
        </thead>
        <tbody>

          <?php
            $table = "";
            $totalArea_2 = 0;


            //dd($areapages_divisi);

            foreach($areapages_divisi as $row){
            $totalArea_2=0;
            $table = $table."\n
                <tr>
                  <td class='text-left'>".$row->outlet_area."</td>";
                  
                     
                     foreach ($segmens_divisi_only as $divisi){ // dinamyc column from table segmens
                         $segmens_divisi = 'OS_'.$divisi->divisi; // because in query use "as OS_"
                         $table = $table."<td class='text-right'>".number_format($row->{$segmens_divisi},0)."</td>"; // dinamyc column of collection use $collection->{$var}

                         $totalArea_2 = $totalArea_2 + $row->{$segmens_divisi}; 
                     }
                  $table = $table."
                  <td class='text-right'><b>".number_format($totalArea_2,0)."</b></td>
                  <td class='text-center'><b>".$row->NOA."</b></td>                    
                </tr>
            ";
            }
            echo $table;
          ?>



        </tbody>
      </table>
    </td></tr></table>


    <br>
    <br>

      <table>
        <tr>
     <td style="background-color: #f5f5f5; padding: 15px; width: 100%; border-radius: 5px"> 

      <br>
      <h5>Summary Berdasarkan Bulan Proyeksi Cair</h5>

      <table class="table mt-2 table-bordered table-hover table-sm w-auto my-3">          
        <thead class="table-secondary">

            <tr>
               <th>Area</th>
               <?php $__currentLoopData = $month_collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <th><?= date('F', mktime(0, 0, 0, $row->ProyBulanCair, 10))  ?></th>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
               <th>Total Area</th>
               <th>NOA Pipeline</th>
            </tr>
        </thead>
        <tbody>

          <?php
            $table = "";
            $totalArea_2 = 0;


            //dd($areapages_bulan_cair);

            foreach($areapages_bulan_cair as $row){
            $totalArea_2=0;
            $table = $table."\n
                <tr>
                  <td class='text-left'>".$row->outlet_area."</td>";
                  
                     
                     foreach ($month_collection as $month){ // dinamyc column from table segmens
                         $bulan_cair = 'OS_'.$month->ProyBulanCair; // because in query use "as OS_"
                         $table = $table."<td class='text-right'>".number_format($row->{$bulan_cair},0)."</td>"; // dinamyc column of collection use $collection->{$var}

                         $totalArea_2 = $totalArea_2 + $row->{$bulan_cair}; 
                     }
                  $table = $table."
                  <td class='text-right'><b>".number_format($totalArea_2,0)."</b></td>
                  <td class='text-center'><b>".$row->NOA."</b></td>                    
                </tr>
            ";
            }
            echo $table;
          ?>



        </tbody>
      </table>















      <br>
      <h5>Summary Berdasarkan Weekly Proyeksi Cair</h5>

      <table class="table mt-2 table-bordered table-hover table-sm w-auto my-3">          
        <thead class="table-secondary">

            <tr>
               <th>Area</th>
               <?php $__currentLoopData = $week_collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <th>
                    <?= date('F', mktime(0, 0, 0, $row->ProyBulanCair, 10))  ?>
                    - Week <?php echo e($row->ProyWeekCair); ?>

                  </th>

               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
               <th>Total Area</th>
               <th>NOA Pipeline</th>
            </tr>
        </thead>
        <tbody>

          <?php
            $table = "";
            $totalArea_2 = 0;


            //dd($areapages_bulan_cair);

            foreach($areapages_week_cair as $row){
            $totalArea_2=0;
            $table = $table."\n
                <tr>
                  <td class='text-left'>".$row->outlet_area."</td>";
                  
                     
                     foreach ($week_collection as $week){ // dinamyc column from table segmens
                         $week_cair = 'OS_'.$week->ProyBulanCair.$week->ProyWeekCair; // because in query use "as OS_"
                         $table = $table."<td class='text-right'>".number_format($row->{$week_cair},0)."</td>"; // dinamyc column of collection use $collection->{$var}

                         $totalArea_2 = $totalArea_2 + $row->{$week_cair}; 
                     }
                  $table = $table."
                  <td class='text-right'><b>".number_format($totalArea_2,0)."</b></td>
                  <td class='text-center'><b>".$row->NOA."</b></td>                    
                </tr>
            ";
            }
            echo $table;
          ?>



        </tbody>
      </table>

    </td></tr></table>
    <br>
    <br>
    <br>







<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL8\pipelineonline\resources\views/v_summaryarea/index.blade.php ENDPATH**/ ?>