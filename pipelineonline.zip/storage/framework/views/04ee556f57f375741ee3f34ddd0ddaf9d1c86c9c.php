

<?php $__env->startSection('title', 'Index'); ?>



<?php $__env->startSection('container'); ?>

      <div class="row mt-2">
        <?php if($message = Session::get('warning')): ?>
          <div class="alert alert-warning" role="alert">
              <?php echo e($message); ?>

          </div>
        <?php endif; ?>
      </div>





<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL8\pipelineonline\resources\views/index.blade.php ENDPATH**/ ?>