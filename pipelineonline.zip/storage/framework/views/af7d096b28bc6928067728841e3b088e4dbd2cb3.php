

<?php $__env->startSection('title', 'Segmen'); ?>

<?php $__env->startSection('assets'); ?>
    <link rel="stylesheet" href="/css/font-awesome.min.css">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>
  
<a href="/segmen">back</a>  
<h3>Edit Segmen</h3>
<br>
<form autocomplete="off" class="form" action="/segmentUpdate/<?php echo e($data->id); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>

  <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Segment Name</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="segmen_ket" value="<?php echo e($data->segmen_ket); ?>">
    </div>
  </div>

  <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label">Divisi</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" name="divisi" value="<?php echo e($data->divisi); ?>">
    </div>
  </div>
 
 <div class="mb-3 row">
    <label for="RezaField" class="col-sm-2 col-form-label"></label>
   <div class="col-auto">
      <button type="submit" class="btn btn-sm btn-primary mb-3">Submit</button>
    </div>
 </div>

</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL8\pipelineonline\resources\views/segmen/show.blade.php ENDPATH**/ ?>