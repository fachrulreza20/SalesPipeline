

<?php $__env->startSection('title', 'Pipeline'); ?>

<?php $__env->startSection('assets'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>

      <div class="float-right">
        <a href='/pipelineExport' class="btn btn-sm btn-success" style="float: right;">Download Excel Pipeline</a>      
      </div>


      <div class="row mt-2">
        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success" role="alert">
              <?php echo e($message); ?>

          </div>
        <?php endif; ?>
      </div>
      <br>
      <h4>Data Pipeline</h4>

      <a href='/pipelineCreate' class="btn btn-sm btn-primary">Add New</a>      
      <table class="table mt-2 table-bordered table-hover table-sm table-responsive">
        <thead class="table-secondary">
          <tr>
            <th class="text-center" scope="col">#</th>
            <th class="text-center" scope="col">Nama Nasabah</th>
            <th class="text-center" scope="col">Nominal</th>
            <th class="text-center" scope="col">Progress</th>
            <th class="text-center" scope="col">Segmen</th>
            <th class="text-center" scope="col">Proyeksi Cair</th>
            <th class="text-center" scope="col">Nomor Loan</th>
            <th class="text-center" scope="col">Employee/Marketing</th>
            <th class="text-center" scope="col">Jabatan</th>
            <th class="text-center" scope="col">Outlet</th>
            <th class="text-center" scope="col">Ket</th>
            <th class="text-center" scope="col">Status</th>
            <th class="text-center" scope="col">Jenis</th>
            <th class="text-center" scope="col">Modified</th>
            <th class="text-center" scope="col">Aksi</th>
          </tr>
        </thead>
        <tbody>

          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
              <td scope="row"><?php echo e($data->firstItem() + $key); ?></td>
              <td><?php echo e($row->pipeline_nama_nasabah); ?></td>
              <td><?php echo e($row->pipeline_nominal); ?></td>
              <td><?php echo e($row->getProgress->progress_ket); ?></td>
              <td><?php echo e($row->getSegment->segmen_ket); ?></td>
              <td>Week <?php echo e($row->pipeline_proyeksiCairWeek); ?> <?= date("F", mktime(0, 0, 0, $row->pipeline_proyeksiCairMonth, 10)); ?></td>
              <td><?php echo e($row->pipeline_noloan); ?></td>
              <td><?php echo e($row->getEmployee->nama); ?></td>
              <td><?php echo e($row->getJabatan->jabatan_ket); ?></td>
              <td><?php echo e($row->getOutlet->outlet_name); ?></td>
              <td><?php echo e($row->pipeline_ket); ?></td>
              <td><?php echo e($row->pipeline_status); ?></td>
              <td><?php echo e($row->pipeline_jenis); ?></td>
              <td><?php echo e($row['updated_at']->format('d M Y h:i')); ?></td>

              <td>
                  <a href="/pipelineShow/<?php echo e($row->id); ?>" class="badge bg-success m-1">Edit</button></a>
                  <a href="#"  class="badge bg-danger m-1" data-id="<?php echo e($row->id); ?>" data-nama="<?php echo e($row->pipeline_nama_nasabah); ?>">Delete</a>
              </td>
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div>
        Showing
        <?php echo e($data->firstItem()); ?>

        to
        <?php echo e($data->lastItem()); ?>

        of
        <?php echo e($data->total()); ?>        
      </div>
      <br>
      <div class="pull-right"> 
        <?php echo e($data->links()); ?>

      </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('bodybottom'); ?>

<script>

  $('.hapus').click(function(){

    var id = $(this).attr('data-id');
    var namapegawai = $(this).attr('data-nama');

    Swal.fire({
      title: 'Anda Yakin?',
      text: "Anda akan menghapus pegawai nama : "+namapegawai+"",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Ya. Hapus Data'
    }).then((result) => {
      if (result.isConfirmed) {
        window.location = "/pipelineDelete/"+id
        Swal.fire(
          'Data Berhasil dihapus!',
          'Sip.',
          'success'
        )
      }
    })
  })

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL8\pipelineonline\resources\views/pipeline/index.blade.php ENDPATH**/ ?>