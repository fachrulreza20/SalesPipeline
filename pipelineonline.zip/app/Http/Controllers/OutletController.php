<?php

namespace App\Http\Controllers;

use App\Models\Outlet;
use Illuminate\Http\Request;
use Auth;
class OutletController extends Controller
{

    public function __construct() 
    {
      $this->middleware('admin');
    }


    public function index()
    {

            $data = Outlet::all();
            return view('outlet.index', compact('data'));
    }

    public function create()
    {
        return view('outlet.create');
    }


    public function store(Request $request)
    {
        
        if(Outlet::create($request->all())){
            return redirect('/outlet')->with('success','Data Outlet Berhasil ditambahkan');
        }

    }

    public function show($id)
    {
        
        $data = Outlet::find($id);
        return view('outlet.show',compact('data')); 
    }



    public function update(Request $request, $id)
    {
        
        $data = Outlet::find($id);
        $data->update($request->all());
        return redirect('/outlet')->with('success','Data berhasil di update');
   }

    public function destroy($id)
    {
        $data = Outlet::find($id);
        $data->delete();
        return redirect('/outlet')->with('success','Data Berhasil dihapus');
    }
}